import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CGPA Converter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Converter(),
    );
  }
}

class Converter extends StatefulWidget {
  const Converter({Key? key}) : super(key: key);

  @override
  State<Converter> createState() => _ConverterState();
}

class _ConverterState extends State<Converter> {

  final myController = TextEditingController();
  String text = "";

  void convert(String cgpa){
    double gpa = double.parse(cgpa);

    if(gpa > 4){
     gpa = 0;
    }
    else if(gpa >= 3.63){
      gpa = (gpa-0.3)/0.037;
    }
    else if(gpa >= 3.25){
      gpa = (gpa-0.29)/0.037;
    }
    else if(gpa >= 2.88){
      gpa = (gpa-0.36)/0.036;
    }
    else if(gpa >= 2.5){
      gpa = (gpa-0.28)/0.037;
    }
    else if(gpa >= 1.8){
      gpa = (gpa+1.65)/0.069;
    }
    else if(gpa >= 1){
      gpa = (gpa+2.16)/0.079;
    }
    else if(gpa >= 0){
      gpa = (gpa)/0.0248;
    }
    else{
      gpa = 0;
    }

    setState(() {
      text = gpa.toStringAsFixed(2);
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("CGPA Converter"),
      ),

      body: Column(
        children: [
          Container(
              padding: EdgeInsets.all(18),
              child: const Text(
                  "Enter Your CGPA to convert it into Percentage",
                style: TextStyle(
                  fontSize: 16
                ),
              ),
          ),

          Container(
            width: 100,
            alignment: Alignment.center,
            child: TextField(
                controller: myController,
                keyboardType: TextInputType.number,
            ),
          ),

          const SizedBox(height: 30,),

          Container(
            width: 200,
            alignment: Alignment.center,
            child: Row(
              children: [
                const Text(
                  "Percentage (%): ",
                ),

                Text(
                  text,
                  style: const TextStyle(
                    fontSize: 24,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30,),

          ElevatedButton(
              onPressed: (){
                convert(myController.text);
              },
              child: Container(
                alignment: Alignment.center,
                width: 100,
                height: 30,
                child: Text(
                  "Convert"
                ),
              )
          ),
        ],
      ),
    );
  }
}

